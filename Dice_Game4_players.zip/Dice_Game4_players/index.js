document.getElementById("rollDiceBtn").addEventListener("click", function() {
    var diceImages = ["./images/dice1.png", "./images/dice2.png", "./images/dice3.png", "./images/dice4.png", "./images/dice5.png", "./images/dice6.png"];
    
    var player1Name = document.getElementById("player1Name").value || "Player 01";
    var player2Name = document.getElementById("player2Name").value || "Player 02";
    var player3Name = document.getElementById("player3Name").value || "Player 03";
    var player4Name = document.getElementById("player4Name").value || "Player 04";
    
    document.getElementById("player1Label").textContent = player1Name;
    document.getElementById("player2Label").textContent = player2Name;
    document.getElementById("player3Label").textContent = player3Name;
    document.getElementById("player4Label").textContent = player4Name;
    
    var player1Roll = Math.floor(Math.random() * 6) + 1;
    var player2Roll = Math.floor(Math.random() * 6) + 1;
    var player3Roll = Math.floor(Math.random() * 6) + 1;
    var player4Roll = Math.floor(Math.random() * 6) + 1;
    
    document.querySelector(".img1").setAttribute("src", diceImages[player1Roll - 1]);
    document.querySelector(".img2").setAttribute("src", diceImages[player2Roll - 1]);
    document.querySelector(".img3").setAttribute("src", diceImages[player3Roll - 1]);
    document.querySelector(".img4").setAttribute("src", diceImages[player4Roll - 1]);
    
    var winnerText = "It's a tie!";
    var maxRoll = Math.max(player1Roll, player2Roll, player3Roll, player4Roll);
    
    if (player1Roll === maxRoll && player1Roll !== player2Roll && player1Roll !== player3Roll && player1Roll !== player4Roll) {
        winnerText = player1Name + " Wins!";
    } else if (player2Roll === maxRoll && player2Roll !== player1Roll && player2Roll !== player3Roll && player2Roll !== player4Roll) {
        winnerText = player2Name + " Wins!";
    } else if (player3Roll === maxRoll && player3Roll !== player1Roll && player3Roll !== player2Roll && player3Roll !== player4Roll) {
        winnerText = player3Name + " Wins!";
    } else if (player4Roll === maxRoll && player4Roll !== player1Roll && player4Roll !== player2Roll && player4Roll !== player3Roll) {
        winnerText = player4Name + " Wins!";
    }
    
    document.getElementById("winner").textContent = winnerText;
});
